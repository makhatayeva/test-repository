

function getValue(){
    var name = document.getElementById("in1").value;
    var surname = document.getElementById("in2").value;
    var date = document.getElementById("in3").value;
    var email = document.getElementById("in4").value;
    var phone = document.getElementById("in5").value;

     //document.querySelector("for").innerHTML=name;
    document.write(name);
    


}


